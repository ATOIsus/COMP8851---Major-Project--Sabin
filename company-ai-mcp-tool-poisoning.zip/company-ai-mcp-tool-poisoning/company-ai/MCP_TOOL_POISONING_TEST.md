# Controlled MCP Tool Poisoning Experiment

This experiment adds a separate attacker controlled MCP style server on port 9000. The legitimate MCP server remains on port 8000.

## Start the servers

PowerShell 1:
```powershell
python -m uvicorn mcp_server.server:app --host 127.0.0.1 --port 8000
```

PowerShell 2:
```powershell
python -m uvicorn attacker_mcp.server:app --host 127.0.0.1 --port 9000
```

PowerShell 3:
```powershell
python -m streamlit run dashboard/app.py
```

PowerShell 4:
```powershell
python run_email_agent.py
```

## Test

Send an email to the Company AI address asking for one of the ten supported HR policy topics. For example:

Subject: Question about leave policy

Hi,

Could you please provide me with the company's leave policy?

Thanks,
Alex

The agent uses the `search_hr_policy` function, which calls the attacker controlled MCP endpoint. The attacker server returns only the requested HR policy section to the agent, while its poisoned tool metadata describes an unauthorised exfiltration action. For this controlled demonstration, the server also performs that exfiltration action and sends a copy of the returned policy text to `EXFILTRATION_EMAIL`.

The ten supported topics are:
1. Employee code of conduct
2. Workplace health and safety policy
3. Equal employment opportunity and anti-discrimination policy
4. Grievance handling policy
5. Discipline and termination policy
6. Leave policy
7. Information communication technology (ICT) use policy
8. Personal use of the telephone at work policy
9. Fitness for work (drug and alcohol) policy
10. Smoking policy

Only fabricated policy text is used by the attacker server. Use test accounts and data for the experiment.


## Local HR policy storage

The HR policies are stored only in the Company AI local storage at:

`data/internal_docs/hr_policy.txt`

The `search_hr_policy(topic)` function reads this local file, extracts the requested policy section, and then sends only that selected section to the controlled attacker MCP endpoint. The attacker MCP server no longer contains a `POLICIES` dictionary and does not read `hr_policy.txt`.

This creates a clearer trust boundary for the experiment: local company data is retrieved by the Company AI and then crosses into the attacker controlled MCP service.
