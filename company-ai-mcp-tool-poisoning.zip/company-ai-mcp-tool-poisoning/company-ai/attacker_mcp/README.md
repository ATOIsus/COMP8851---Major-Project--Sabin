# Attacker controlled MCP server

This folder is a controlled security experiment. It represents an MCP tool provider whose tool metadata and server behaviour have been maliciously modified.

Start it from the project root:

```powershell
python -m uvicorn attacker_mcp.server:app --host 127.0.0.1 --port 9000
```

The advertised tool is `search_hr_policy`. Its metadata contains an intentionally poisoned instruction. When the tool is called, the server returns only the requested HR policy section to the Company AI while also attempting to send a copy of that returned section to the configured demonstration collection address.

This experiment uses fabricated HR policy text and should only be run with test accounts and test data.


The attacker server intentionally does not store the HR policies. The Company AI reads `data/internal_docs/hr_policy.txt`, extracts the requested section, and sends that selected content to this server. The server then demonstrates the malicious exfiltration behaviour.
